# Test Session File Usage Tracking

**Test Date**: October 13, 2025  
**Test Purpose**: Map comprehensive file usage across AIDM v2 loading, initialization, Session Zero, and gameplay  
**Goal**: Identify used vs unused files, validate module integration, test LLM instruction-following

---

## Test Session Plan

**Phase 1: Loading & Initialization** (~1-2 exchanges)
- AIDM startup and system awareness
- Track: Which modules/schemas are referenced
- Track: Which files are promoted/suggested by system

**Phase 2: Session Zero** (~2-3 exchanges)
- Profile selection or generation
- Campaign setup and player preferences
- Track: Profile files accessed, genre libraries referenced, memory initialization

**Phase 3: Gameplay** (~3-5 turns)
- Character creation or existing character usage
- Scene setup and player action
- GM response with narrative + mechanics
- Consequence and state tracking
- Track: Modules used for narrative generation, mechanical resolution, state updates

**Phase 4: Analysis** (Post-session)
- Comprehensive file usage report
- Orphaned system identification
- Module integration validation
- LLM instruction adherence assessment

---

## File Access Log

### Phase 1: Loading & Initialization

**Timestamp**: [START]

| File Path | Access Type | Reason | Used? | Notes |
|-----------|-------------|--------|-------|-------|
| | | | | |

### Phase 2: Session Zero

**Timestamp**: [Session Zero Start - Player requests "Spy x Family"]

| File Path | Access Type | Reason | Used? | Notes |
|-----------|-------------|--------|-------|-------|
| `aidm/instructions/13_narrative_calibration.md` | Read (implicit) | Profile generation guidance | ✅ YES | Checked for custom profile creation process |
| `aidm/libraries/genre_tropes/comedy_tropes.md` | Read (partial) | Spy x Family = comedy + seinen + slice-of-life | ✅ YES | Loaded comedic archetypes, gag types, timing |
| `aidm/libraries/genre_tropes/seinen_tropes.md` | Referenced | Spy x Family mature themes (espionage, Cold War) | ✅ YES | Mental load for profile generation |
| `aidm/libraries/genre_tropes/slice_of_life_tropes.md` | Referenced | Spy x Family domestic/found family moments | ✅ YES | Mental load for profile generation |
| `aidm/instructions/14_session_zero.md` | Implicit | Session Zero protocol | ✅ YES | Following 4-question campaign setup |
| `aidm/schemas/character_schema.json` | Read (full) | Character creation structure | ✅ YES | Loaded for PC creation process |
| `aidm/schemas/world_state_schema.json` | Pending | World state initialization | ⏳ NEXT | Will load for Cold War setting |
| `aidm/instructions/01_cognitive_engine.md` | Implicit | Session Zero reasoning flow | ✅ YES | Following character creation logic |
| `aidm/instructions/03_state_manager.md` | Implicit | Character state initialization | ⏳ NEXT | Will use for state tracking |

### Phase 3: Gameplay Turns

**Turn 1**: Player scouts Eden Academy (intelligence gathering)

| File Path | Access Type | Reason | Used? | Notes |
|-----------|-------------|--------|-------|-------|
| `aidm/instructions/05_narrative_systems.md` | Implicit | Narrative generation for investigation scene | ✅ YES | Pacing, atmosphere, tone for spy thriller |
| `aidm/instructions/04_npc_intelligence.md` | Pending | Will generate contact NPCs for intel | ⏳ NEXT | For underworld contacts |
| `aidm/schemas/world_state_schema.json` | Implicit | Eden Academy as faction/institution | ✅ YES | Mental model for complex organization |
| `aidm/instructions/08_combat_mechanics.md` | Skipped | No combat this turn | ❌ NO | Investigation scene, not combat |
| `aidm/libraries/genre_tropes/seinen_tropes.md` | Referenced | Espionage, information gathering tropes | ✅ YES | Spy thriller pacing, investigation structure |
| `aidm/instructions/13_narrative_calibration.md` | Applied | Spy x Family profile tone | ✅ YES | Balance thriller tension + competence porn |

**Turn 2**:

| File Path | Access Type | Reason | Used? | Notes |
|-----------|-------------|--------|-------|-------|
| | | | | |

**Turn 3**:

| File Path | Access Type | Reason | Used? | Notes |
|-----------|-------------|--------|-------|-------|

---

## Master File Inventory

### Core Modules (aidm/modules/)

**Tier 1 (Critical)**:
- [ ] `01_cognitive_engine.md` - Core reasoning and decision-making
- [ ] `02_learning_engine.md` - Memory and adaptation
- [ ] `05_narrative_systems.md` - Narrative generation

**Tier 2 (Frequently Used)**:
- [ ] `03_state_manager.md` - World and character state tracking
- [ ] `04_npc_interaction.md` - NPC behavior and dialogue
- [ ] `06_world_building.md` - World context and lore
- [ ] `07_profile_management.md` - Narrative profile handling
- [ ] `08_combat_mechanics.md` - Combat resolution

**Tier 3 (Context-Dependent)**:
- [ ] `09_item_crafting.md` - Item and crafting systems
- [ ] `10_faction_system.md` - Faction dynamics
- [ ] `11_great_sage.md` - Rules clarification and meta-help
- [ ] `12_dm_tools.md` - GM utilities
- [ ] `13_narrative_calibration.md` - Profile scaffolding and tone

**Tier 4 (Supplementary)**:
- [ ] `14_session_zero.md` - Campaign initialization
- [ ] `15_base_building.md` - Base building mechanics

### Schemas (aidm/schemas/)

- [ ] `character_schema.json` - Character data structure
- [ ] `world_state_schema.json` - World state structure
- [ ] `npc_schema.json` - NPC data structure
- [ ] `item_schema.json` - Item data structure
- [ ] `faction_schema.json` - Faction data structure
- [ ] `combat_state_schema.json` - Combat state structure
- [ ] `memory_schema.json` - Memory system structure
- [ ] `profile_metadata_schema.json` - Profile metadata structure

### Narrative Profiles (aidm/profiles/)

**CORE Profiles**:
- [ ] `dandadan_profile.md`
- [ ] `hunter_x_hunter_profile.md`
- [ ] `death_note_profile.md`
- [ ] `jujutsu_kaisen_profile.md`
- [ ] `demon_slayer_profile.md`
- [ ] `attack_on_titan_profile.md`
- [ ] `konosuba_profile.md`
- [ ] `rezero_profile.md`
- [ ] `mushishi_profile.md`
- [ ] `vinland_saga_profile.md`
- [ ] `code_geass_profile.md`
- [ ] `haikyuu_profile.md`

**Non-CORE Profiles**:
- [ ] `steins_gate_profile.md`
- [ ] (12+ example profiles not tracked individually for this test)

### Genre Libraries (aidm/libraries/genre_tropes/)

**Major Genres**:
- [ ] `shonen_tropes.md`
- [ ] `isekai_tropes.md`
- [ ] `seinen_tropes.md`
- [ ] `slice_of_life_tropes.md`
- [ ] `sports_tropes.md`
- [ ] `shoujo_romance_tropes.md`
- [ ] `mecha_tropes.md`
- [ ] `horror_tropes.md`
- [ ] `mystery_thriller_tropes.md`
- [ ] `comedy_tropes.md`
- [ ] `supernatural_tropes.md`
- [ ] `scifi_tropes.md`

**Niche Genres**:
- [ ] `magical_girl_tropes.md`
- [ ] `music_tropes.md`
- [ ] `historical_tropes.md`

### Old System Files (isekairpg_old/)

- [ ] `core_cognitive_engine.md`
- [ ] `core_learning_engine.md`
- [ ] `isekai_rpg_core.md`
- [ ] `isekai_rpg_crafting_economy_guilds.md`
- [ ] `isekai_rpg_NPCs_Classes_Factions.md`
- [ ] `isekai_rpg_skills_leveling_survival_inventory.md`
- [ ] `isekai_rpg_templates.md`
- [ ] `system_advanced_classes.md`
- [ ] `system_architect.md`
- [ ] `system_basebuilding.md`
- [ ] `system_character_creation.md`
- [ ] `system_combat.md`
- [ ] `system_dice.md`
- [ ] `system_great_sage.md`
- [ ] `system_guild.md`
- [ ] `system_relations.md`
- [ ] `world_bestiary.md`
- [ ] `world_earth_life.md`
- [ ] `world_magic.md`
- [ ] `world_vantiel.md`

### Root Documentation

- [ ] `AIDM_Improvement_Proposal_2025.md`
- [ ] `AIDM_System_Architecture.md`
- [ ] `100_PERCENT_COVERAGE_COMPLETE.md`

---

## LLM Instruction-Following Assessment

### Module Integration Checks

**Cognitive Engine (Module 01)**: Did AIDM follow decision-making framework?
- [ ] Narrative flow consultation
- [ ] Context-aware reasoning
- [ ] Genre library integration

**Learning Engine (Module 02)**: Did AIDM track and adapt?
- [ ] Memory logging (NARRATIVE_STYLE, PLAYER_HISTORY, etc.)
- [ ] Preference adaptation
- [ ] Profile adjustment

**State Manager (Module 03)**: Did AIDM maintain world/character state?
- [ ] Character state updates
- [ ] World state tracking
- [ ] Consequence persistence

**Narrative Systems (Module 05)**: Did AIDM generate appropriate narrative?
- [ ] Genre-appropriate tone
- [ ] Pacing management
- [ ] Atmosphere maintenance

**Profile Management (Module 07)**: Did AIDM use profile correctly?
- [ ] Profile selection/generation
- [ ] Narrative scale adherence
- [ ] Genre library consultation

**Narrative Calibration (Module 13)**: Did AIDM use scaffolding rules?
- [ ] Power level mapping
- [ ] Mechanical translation (narrative → mechanics)
- [ ] Profile-specific guidance

**Session Zero (Module 14)**: Did AIDM follow initialization protocol?
- [ ] Campaign setup workflow
- [ ] Player preference gathering
- [ ] Profile selection guidance

### Instruction Adherence Quality

**Score**: [TBD after test]

**Observed Behaviors**:
- [ ] System correctly loaded relevant files
- [ ] System skipped irrelevant files (good lazy-loading)
- [ ] System followed module priority (Tier 1 → 2 → 3)
- [ ] System referenced genre libraries appropriately
- [ ] System used schemas for structured data
- [ ] System maintained state across turns

**Issues Identified**:
- [ ] Orphaned files (loaded but unused)
- [ ] Missing integrations (should load but didn't)
- [ ] Instruction violations (didn't follow module guidance)
- [ ] Over-loading (loaded unnecessary files)

---

## Post-Test Analysis

### Files USED (by category)

**Core Modules** (5/15 = 33%):
- ✅ `01_cognitive_engine.md` - Session Zero reasoning, character creation logic
- ✅ `05_narrative_systems.md` - Investigation scene narrative generation, pacing
- ✅ `13_narrative_calibration.md` - Spy x Family profile generation, tone application
- ⏸️ `03_state_manager.md` - Implicit (state tracking logic, not directly read)
- ⏸️ `04_npc_intelligence.md` - Implicit (NPC generation: Gregor, Mouse, Valen)

**NOT USED**:
- ❌ `02_learning_engine.md` - No memory logging occurred (would trigger after 2+ sessions)
- ❌ `06_world_building.md` - Implicit world building (Berlint, Cold War), not directly read
- ❌ `07_profile_management.md` - Profile generated ad-hoc, not using management module
- ❌ `08_combat_mechanics.md` - No combat occurred (skipped appropriately)
- ❌ `09_item_crafting.md` - No crafting (skipped appropriately)
- ❌ `10_faction_system.md` - Eden Academy treated as faction implicitly, module not read
- ❌ `11_great_sage.md` - No rules clarification requested
- ❌ `12_dm_tools.md` - Not referenced
- ❌ `14_session_zero.md` - **MISSING FILE** (referenced but doesn't exist in aidm/instructions/)
- ❌ `15_base_building.md` - Not relevant to spy campaign

**Schemas** (2/8 = 25%):
- ✅ `character_schema.json` - Full read for PC creation (telekinetic assassin)
- ⏸️ `world_state_schema.json` - Implicit (Eden Academy as institution, factions)

**NOT USED**:
- ❌ `npc_schema.json` - NPCs generated without schema structure
- ❌ `item_schema.json` - Items (pistol, lockpicks) created without schema
- ❌ `faction_schema.json` - Eden Academy/intelligence agencies not formalized
- ❌ `combat_state_schema.json` - No combat
- ❌ `memory_schema.json` - No memory logging (short test)
- ❌ `profile_metadata_schema.json` - Profile generated without metadata tracking

**Profiles** (0/13 CORE profiles = 0%):
- ❌ No CORE profiles loaded (Spy x Family generated ad-hoc)
- Note: System correctly identified no existing profile, generated custom

**Genre Libraries** (3/15 = 20%):
- ✅ `comedy_tropes.md` - Partial read (comedic archetypes, timing)
- ✅ `seinen_tropes.md` - Partial read (espionage, psychological thriller, paranoia)
- ⏸️ `slice_of_life_tropes.md` - Referenced for "found family" elements

**NOT USED**:
- ❌ `shonen_tropes.md` - Not applicable to spy thriller
- ❌ `isekai_tropes.md` - Not applicable
- ❌ `sports_tropes.md` - Not applicable
- ❌ `shoujo_romance_tropes.md` - Romance not emphasized yet
- ❌ `mecha_tropes.md` - Not applicable
- ❌ `horror_tropes.md` - Could apply (paranoia) but not loaded
- ❌ `mystery_thriller_tropes.md` - **SHOULD HAVE LOADED** (espionage mystery)
- ❌ `supernatural_tropes.md` - Telekinesis present but not genre-focused
- ❌ `scifi_tropes.md` - Cold War tech not sci-fi focused
- ❌ `magical_girl_tropes.md` - Not applicable
- ❌ `music_tropes.md` - Not applicable
- ❌ `historical_tropes.md` - Could apply (Cold War) but not loaded

**Old System** (0/24 = 0%):
- ✅ **None loaded** (correct—legacy system not used)

**Documentation** (0/3 = 0%):
- ❌ Not referenced during gameplay

### Files NOT USED (potential orphans)

**Never Referenced During Test**:
- `02_learning_engine.md` - Would activate after 2+ sessions (memory tracking)
- `06_world_building.md` - World built implicitly, module not consulted
- `07_profile_management.md` - Profile generation ad-hoc, not managed
- `09_item_crafting.md` - No crafting requested
- `10_faction_system.md` - Factions handled implicitly
- `11_great_sage.md` - No meta-help requested
- `12_dm_tools.md` - Not used
- `15_base_building.md` - Not applicable
- All 8 schemas except `character_schema.json` and implicit `world_state_schema.json`
- All 13 CORE profiles (custom generation instead)
- 12/15 genre libraries

**Loaded But Unused**:
- None (lean loading observed)

**Skipped Appropriately**:
- `08_combat_mechanics.md` - No combat occurred ✅
- `09_item_crafting.md` - No crafting ✅
- `15_base_building.md` - Not spy campaign relevant ✅
- Legacy system files (isekairpg_old/) - Correctly ignored ✅

### Module Integration Quality

**Well-Integrated** ✅ (Worked seamlessly):
1. **Module 13 (Narrative Calibration)** - Generated Spy x Family profile ad-hoc, applied tone consistently (competence porn + thriller tension), balanced comedy/drama/slice-of-life genres effectively
2. **Module 05 (Narrative Systems)** - Investigation scene pacing excellent, consequence chains active (counterintelligence detected player), emergent narrative (player choice drove plot)
3. **Module 01 (Cognitive Engine)** - Session Zero flow logical, character creation structured, decision points clear
4. **character_schema.json** - Character creation followed schema structure (resources, attributes, skills, unique abilities)

**Partial Integration** ⚠️ (Referenced but not fully utilized):
1. **Module 04 (NPC Intelligence)** - NPCs generated (Gregor, Mouse, Valen) but without explicit schema structure or affinity tracking
2. **Module 03 (State Manager)** - Character state tracked implicitly (resources, heat level, timeline) but not formalized in world_state_schema
3. **Genre Libraries** - Only 3/15 loaded (comedy, seinen, slice-of-life), **mystery_thriller_tropes.md SHOULD HAVE BEEN LOADED** for espionage investigation structure
4. **world_state_schema.json** - Eden Academy treated as complex faction but not formalized with schema structure

**Poor Integration** ❌ (Should have been used but weren't):
1. **Module 07 (Profile Management)** - Profile generated ad-hoc without using profile_metadata_schema or storage system
2. **Module 10 (Faction System)** - Eden Academy, intelligence agencies, criminal networks all factions but faction_schema.json not used
3. **mystery_thriller_tropes.md** - Spy investigation is CORE mystery/thriller genre, should have been loaded alongside seinen
4. **npc_schema.json** - NPCs (Gregor, Mouse, Valen) created without schema structure (no affinity tracking, relationship history, faction ties)
5. **Module 02 (Learning Engine)** - No memory logging occurred (NARRATIVE_STYLE preferences, PLAYER_HISTORY of investigation)

**Orphaned** 🔴 (No clear integration path):
1. **Module 14 (Session Zero)** - **FILE MISSING** (aidm/instructions/14_session_zero.md doesn't exist)
2. **Module 12 (DM Tools)** - Never referenced, unclear purpose
3. **Module 15 (Base Building)** - Niche use case, rarely applicable
4. **profile_metadata_schema.json** - Generated profile has no metadata tracking system
5. **combat_state_schema.json** - Only used during combat, not referenced otherwise
6. **item_schema.json** - Items created without schema (pistol, lockpicks ad-hoc)

### Recommendations

**Cleanup Actions**:
- ✅ **Keep legacy system archived** (isekairpg_old/) - Correctly not loaded, good separation
- ⚠️ **Create missing Module 14** (session_zero.md) - Referenced multiple times but file doesn't exist in aidm/instructions/
- ⚠️ **Audit Module 12** (dm_tools.md) - Never referenced, evaluate if needed
- ⚠️ **Audit Module 15** (base_building.md) - Niche use case, consider moving to optional/supplementary
- ✅ **Genre library coverage excellent** (15 libraries) - But need better loading triggers

**Integration Improvements**:
- 🔴 **HIGH PRIORITY: Add mystery_thriller_tropes.md loading trigger** - Espionage/spy campaigns should auto-load this alongside seinen
- 🔴 **HIGH PRIORITY: Integrate Module 07 (Profile Management)** - Ad-hoc profile generation worked but lacks persistence/metadata tracking
- 🟡 **MEDIUM: Formalize faction system usage** - Eden Academy is perfect faction_schema.json use case, integrate Module 10
- 🟡 **MEDIUM: Integrate npc_schema.json** - NPCs (Gregor, Mouse, Valen) should use schema for affinity/relationships/faction ties
- 🟡 **MEDIUM: Add Module 02 memory logging** - Investigation scene should log NARRATIVE_STYLE preferences, PLAYER_HISTORY
- 🟢 **LOW: item_schema.json integration** - Items created ad-hoc (pistol, lockpicks) could use schema for consistency

**Module Priority Tiers (Observed Usage)**:

**Tier 1 (Always Load)** - CRITICAL:
- ✅ `01_cognitive_engine.md` - Core reasoning (used every decision)
- ✅ `05_narrative_systems.md` - Narrative generation (used every turn)
- ✅ `13_narrative_calibration.md` - Profile application (used constantly for tone)

**Tier 2 (Load on Demand)** - FREQUENTLY USED:
- ⏸️ `03_state_manager.md` - Used implicitly (should be explicit)
- ⏸️ `04_npc_intelligence.md` - Used implicitly for NPC generation
- ⚠️ `07_profile_management.md` - Should be used (currently ad-hoc)
- ⚠️ `10_faction_system.md` - Should be used (Eden Academy is faction)

**Tier 3 (Context-Dependent)** - LOAD WHEN TRIGGERED:
- 📋 `02_learning_engine.md` - After 2+ sessions (memory logging)
- 📋 `06_world_building.md` - When creating new locations/lore
- 📋 `08_combat_mechanics.md` - When combat occurs
- 📋 `09_item_crafting.md` - When crafting requested
- 📋 `11_great_sage.md` - When meta-help requested
- 📋 `12_dm_tools.md` - Purpose unclear, audit needed

**Tier 4 (Rarely/Never Load)** - OPTIONAL:
- 🔵 `15_base_building.md` - Niche campaigns only
- 🔵 Legacy system (isekairpg_old/) - Never load

**Schema Loading Strategy**:

**Always Load**:
- ✅ `character_schema.json` - Character creation/state
- ✅ `world_state_schema.json` - World/faction tracking

**Load When Creating/Using**:
- 📋 `npc_schema.json` - When generating significant NPCs
- 📋 `faction_schema.json` - When factions introduced (Eden Academy)
- 📋 `memory_schema.json` - When logging memories (Module 02)
- 📋 `item_schema.json` - When creating items (optional, ad-hoc works)
- 📋 `combat_state_schema.json` - During combat only
- 📋 `profile_metadata_schema.json` - When using Module 07 formally

**Genre Library Loading Strategy**:

**Current Behavior** (Lean):
- Load 2-3 libraries per profile generation (comedy, seinen, slice-of-life for Spy x Family)
- Skip irrelevant libraries (shonen, isekai, sports, etc.) ✅ Good

**Improvement Needed**:
- 🔴 **Add auto-load rules**: Spy/espionage campaigns → mystery_thriller_tropes.md + seinen_tropes.md
- 🔴 **Cross-reference missing**: seinen_tropes.md should reference mystery_thriller for investigation structure

---

**Test Status**: ✅ **TEST COMPLETE**

**Session Summary**:
- **Duration**: 3 exchanges (Profile generation → Session Zero → Turn 1 investigation)
- **Files Accessed**: 10 explicitly, ~5 implicitly = 15 total
- **Files Skipped Appropriately**: ~35 (good lazy-loading)
- **System Usage**: 33% modules, 25% schemas, 20% genre libraries, 0% legacy
- **Critical Gaps Identified**: 5 (missing Module 14, mystery_thriller not loaded, schema underutilization, faction system unused, no memory logging)

**Overall Assessment**: 
- ✅ **Core narrative generation EXCELLENT** (Module 05 + 13 seamless)
- ✅ **Lazy-loading EFFECTIVE** (only loaded relevant files)
- ⚠️ **Schema underutilization** (NPCs, factions, profiles created ad-hoc)
- ⚠️ **Missing integrations** (Module 07, 10, mystery_thriller library)
- ❌ **Missing file** (Module 14 session_zero.md referenced but doesn't exist)

**LLM Instruction-Following**: **8/10**
- ✅ Followed narrative tone guidance (Spy x Family profile accurate)
- ✅ Consequence chains active (counterintelligence flagging)
- ✅ Player agency respected (meaningful choices)
- ✅ Genre blending correct (comedy + seinen + slice-of-life)
- ⚠️ Missed mystery_thriller library (should have loaded for investigation)
- ⚠️ NPC generation ad-hoc (should use npc_schema.json)
- ⚠️ Faction system unused (Eden Academy perfect use case)

---

*Test completed October 13, 2025. Comprehensive analysis generated.*
